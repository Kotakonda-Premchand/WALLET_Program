package com.cg.project.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSearchStepDefinition {

	
    @Given("^User is on Google HomePage$")
    public void user_is_on_Google_HomePage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @When("^User search for 'Agile Methodology'$")
    public void user_search_for_Agile_Methodology() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^All links should display with 'Agile Methodology'$")
    public void all_links_should_display_with_Agile_Methodology() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }
	
	
}

